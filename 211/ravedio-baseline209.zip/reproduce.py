"""blender -b --python reproduce.py -- <packed.blend> <output.png> [120|512]
No E: drive paths, historical scripts, fonts or internet are required.
"""
import bpy,sys
from pathlib import Path
args=sys.argv[sys.argv.index('--')+1:];source=Path(args[0]).resolve();output=Path(args[1]).resolve();size=int(args[2]) if len(args)>2 else 512
assert size in [120,512];bpy.ops.wm.open_mainfile(filepath=str(source));s=bpy.context.scene
# Camera, light powers/sizes/transforms, world and AgX settings remain saved.
s.render.resolution_x=s.render.resolution_y=size;s.render.resolution_percentage=100;s.cycles.samples=64 if size==512 else 40;s.cycles.device='CPU';s.render.filepath=str(output);s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGBA'
bpy.ops.render.render(scene=s.name,write_still=True)
